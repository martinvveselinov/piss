#include "implementation.h"

void MyActionHandler::onWorkerSend(int minute, ResourceType resource)
{
	std::cout << "W " << minute << " ";

	if (resource == ResourceType::banana)
	{
		std::cout << "banana\n";
	}
	else if (resource == ResourceType::schweppes)
	{
		std::cout << "schweppes\n";
	}
}



void MyActionHandler::onWorkerBack(int minute, ResourceType resource)
{
	std::cout << "D " << minute << " ";
	switch (resource)
	{
	case ResourceType::banana:
		std::cout << "banana";
		break;
	case ResourceType::schweppes:
		std::cout << "schweppes";
		break;
	}

	std::cout << std::endl;
}

void MyActionHandler::onClientDepart(int index, int minute, int banana, int schweppes)
{
	std::cout << index << " " << minute << " " << banana << " " << schweppes << std::endl;
}

void MyStore::setActionHandler(ActionHandler *handler)
{
	actionHandler = handler;
}

void MyStore::init(int workerCount, int startBanana, int startSchweppes)
{
	workers = workerCount;
	totalBananas = startBanana;
	totalSchweppes = startSchweppes;
}

void MyStore::addClients(const Client *clients, int count)
{
	if (!clients)
	{
		throw std::invalid_argument("Empty client list!");
	}

	store_clients.initialize(clients, count);
}

unsigned int MyStore::orderedBananas()
{
	unsigned int total = 0;

	for (int i = 0; i < workersOnDuty.size(); i++)
	{
		if (workersOnDuty[i].resource == ResourceType::banana)
		{
			total += AMOUNT;
		}
	}

	return total;
}

unsigned int MyStore::orderedSchweppes()
{
	unsigned int total = 0;

	for (int i = 0; i < workersOnDuty.size(); i++)
	{
		if (workersOnDuty[i].resource == ResourceType::schweppes)
		{
			total += AMOUNT;
		}
	}

	return total;
}

void MyStore::restockBananas(int minute, unsigned int requiredBananas)
{
	while (requiredBananas > orderedBananas() + totalBananas && workers != 0)
	{
		Worker worker_to_be_sent(ResourceType::banana, minute + TIME);
		workers--;
		workersOnDuty.push_back(Worker(ResourceType::banana, minute + TIME));

		actionHandler->onWorkerSend(minute, ResourceType::banana);

	}
}

void MyStore::restockSchweppes(int minute, unsigned int requiredSchweppes)
{
	while (requiredSchweppes > orderedSchweppes() + totalSchweppes && workers != 0)
	{
		Worker worker_to_be_sent(ResourceType::schweppes, minute + TIME);
		workers--;
		workersOnDuty.push_back(Worker(ResourceType::schweppes, minute + TIME));

		actionHandler->onWorkerSend(minute, ResourceType::schweppes);
	}
}
void MyStore::restock(int minute, unsigned int requiredBananas, unsigned int requiredSchweppes)
{
	restockBananas(minute, requiredBananas);
	restockSchweppes(minute, requiredSchweppes);
}

void MyStore::serveClients(int minute)
{

	while (true)
	{
		
		try
		{
			Client_result cur = store_clients.current(minute);
		}
		catch (const std::invalid_argument &err)
		{
			return;
		}

		Client_result cur = store_clients.current(minute);

		// in_hurry represents client that has to leave at the moment
		if (cur.in_hurry)
		{
			int bananas_taken = calculateBanana(cur.client);
			totalBananas -= bananas_taken;
			int schweppes_taken = calculateSchweppes(cur.client);
			totalSchweppes -= schweppes_taken;

			actionHandler->onClientDepart(cur.id, minute, bananas_taken, schweppes_taken);

			store_clients.removeClient(cur.id);
		}

		try
		{
			Client_result cur = store_clients.current(minute);
		}
		catch (const std::invalid_argument &err)
		{
			return;
		}

		Client_result cur1 = store_clients.current(minute);

		if (cur1.client.banana <= totalBananas && cur1.client.schweppes <= totalSchweppes)
		{
			int bananas_taken = calculateBanana(cur1.client);
			totalBananas -= bananas_taken;
			int schweppes_taken = calculateSchweppes(cur1.client);
			totalSchweppes -= schweppes_taken;

			actionHandler->onClientDepart(cur1.id, minute, bananas_taken, schweppes_taken);

			store_clients.removeClient(cur1.id);
			continue;
		}

		break;
	}
}

void MyStore::advanceTo(int minute)
{
	// for loop calculating events for every minute
	for (int i = 0; i <= minute; i++)
	{
		fillStore(i);
		store_clients.clientArrive(i);

		unsigned int requiredBananas = store_clients.getRequiredBananas();
		unsigned int requiredSchweppes = store_clients.getRequiredSchweppes();
		restock(i, requiredBananas, requiredSchweppes);
		serveClients(i);

	}
}

int MyStore::calculateBanana(const Client &client)
{
	int bananas_signed = totalBananas;
	return (bananas_signed - client.banana > 0) ? client.banana : bananas_signed;
}

int MyStore::calculateSchweppes(const Client &client)
{
	int schweppes_signed = totalSchweppes;
	return (schweppes_signed - client.schweppes > 0) ? client.schweppes : schweppes_signed;
}

void MyStore::fillStore(unsigned int minute)
{
	int workersOn = workersOnDuty.size();
	int temp = 0;
	for (std::size_t i = 0; i < workersOn; i++)
	{
		// get all workers that arrive in the current minute
		if (workersOnDuty[i - temp].timeOfArrival == minute)
		{
			switch (workersOnDuty[i - temp].resource)
			{
			case ResourceType::banana:
				totalBananas += AMOUNT;
				break;
			case ResourceType::schweppes:
				totalSchweppes += AMOUNT;
				break;
			}

			actionHandler->onWorkerBack(workersOnDuty[i - temp].timeOfArrival, workersOnDuty[i - temp].resource);

			workersOnDuty.erase(workersOnDuty.begin() + ((i - temp) * sizeof(Worker)));
			workers++;
			temp++;
		}
	}
}

int MyStore::getBanana() const
{
	return totalBananas;
}

int MyStore::getSchweppes() const
{
	return totalSchweppes;
}

Store *createStore()
{
	return new MyStore;
}