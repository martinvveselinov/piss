#pragma once

#include "interface.h"
#include "clientsQueue.h"
#include <vector>
#include <iostream>

const unsigned int TIME = 60;
const unsigned int AMOUNT = 100;

// represents workers that are out for delivery
struct Worker
{
	ResourceType resource;
	unsigned int timeOfArrival;

	Worker(ResourceType type, unsigned int time)
		: resource(type), timeOfArrival(time) {}
};

struct MyActionHandler : ActionHandler
{
	void onWorkerSend(int minute, ResourceType resource);
	void onWorkerBack(int minute, ResourceType resource);
	void onClientDepart(int index, int minute, int banana, int schweppes);
};

struct MyStore : Store
{
private:
	ActionHandler *actionHandler = nullptr;
	ClientsQueue store_clients;

	unsigned int totalBananas;
	unsigned int totalSchweppes;
	unsigned int requiredBananas;
	unsigned int requiredSchweppes;


	std::vector<Worker> workersOnDuty;
	unsigned int workers;

public:
	void setActionHandler(ActionHandler *handler) override;

	void init(int workerCount, int startBanana, int startSchweppes) override;

	void addClients(const Client *clients, int count) override;

	

	unsigned int orderedBananas();

	unsigned int orderedSchweppes();

	void restockBananas(int minute, unsigned int requiredBananas);

	void restockSchweppes(int minute, unsigned int requiredSchweppes);

	void restock(int minute, unsigned int requiredBananas, unsigned int requiredSchweppes);

	void serveClients(int minute);

	

	// calculates action for ever minute that is <= given minute
	void advanceTo(int minute) override;

	// calculating amount of bananas that the client takes
	int calculateBanana(const Client &client);

	// calculating amount of schweppes that the client takes
	int calculateSchweppes(const Client &client);

	// get all workers that return in the current minute and update the resources
	void fillStore(unsigned int minute);

	int getBanana() const;

	int getSchweppes() const;
};

Store *createStore();