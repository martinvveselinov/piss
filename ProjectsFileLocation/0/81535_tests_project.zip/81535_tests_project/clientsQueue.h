#pragma once

#include <vector>
#include "interface.h"

// structure to obtain more information about the client
struct Client_result
{
    int id;
    Client &client;
    bool in_hurry;
};

class ClientsQueue
{
private:
    // number of different ids
    unsigned int count;

    // vector to store ids
    std::vector<int> ids;
    
    std::vector<Client> clientList;
    // client in the queue at the current minute
    std::vector<Client> clients;

    // already ordered requests
    int clientsServedBanana = 0;
    int clientsServedSchweppes = 0;

public:
    void initialize(const Client *inClientList, int size);
    // adds clients that arrive in the current minute
    void clientArrive(int minute);
    // retruns the current client
    const Client_result current(int minute);
    // remove client by id
    void removeClient(int id);

    // amount of bananas and schweppeses that has to be ordered
    unsigned int getRequiredBananas();
    unsigned int getRequiredSchweppes();
};
