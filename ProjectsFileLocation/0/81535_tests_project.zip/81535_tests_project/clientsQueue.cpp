#include "clientsQueue.h"
#include <iostream>

void ClientsQueue::initialize(const Client *inClientList, int size)
{
    // clearing data
    count = 0;
    clientList.clear();
    clients.clear();
    ids.clear();

    for (std::size_t i = 0; i < size; i++)
    {
        clientList.push_back(inClientList[i]);
    }
}

void ClientsQueue::clientArrive(int minute)
{
    if (clientList.size() > count && clientList[count].arriveMinute == minute)
    {
        // client entering the store
        clients.push_back(clientList[count]);
        // assign id
        ids.push_back(count);

        // count clients that have arrived
        clientsServedBanana++;
        clientsServedSchweppes++;

        count++;
    }
}

const Client_result ClientsQueue::current(int minute)
{
    // let clients in if such exist
    clientArrive(minute);

    // throw if there is no client in the queue
    if (clients.size() < 1)
    {
        throw std::invalid_argument("No clients");
    }

    // return current client whether he is in a hurry or not
    for (int i = 0; i < clients.size(); i++)
    {
        if (minute == clients[i].arriveMinute + clients[i].maxWaitTime)
        {
            // client must leave
            return {ids[i], clients[i], true};
        }
    }

    // client on turn
    return {ids[0], clients[0], false};
}

void ClientsQueue::removeClient(int id)
{
    for (int i = 0; i < ids.size(); i++)
    {
        if (ids[i] == id)
        {
            ids.erase(ids.begin() + i);
            clients.erase(clients.begin() + i);
        }
    }
}

unsigned int ClientsQueue::getRequiredBananas()
{
    unsigned int total = 0;

    for (int i = clients.size() - 1, j = clientsServedBanana; j > 0; i--, j--)
    {
        total += clients[i].banana;
    }

    clientsServedBanana = 0;

    return total;
}

unsigned int ClientsQueue::getRequiredSchweppes()
{
    unsigned int total = 0;

    for (int i = clients.size() - 1, j = clientsServedSchweppes; j > 0; i--, j--)
    {
        total += clients[i].schweppes;
    }

    clientsServedSchweppes = 0;

    return total;
}