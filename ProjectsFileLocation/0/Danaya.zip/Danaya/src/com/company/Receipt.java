package com.company;
import java.time.LocalDateTime; // Import the LocalDateTime class
import java.util.ArrayList; // import the ArrayList class

public class Receipt {
    private int number;
    private Cashier cashier;
    private LocalDateTime date;
            //myDateObj = LocalDateTime.now();
    private double totalPrice;
    private int[] products;
    public Receipt(int number, Cashier cashier, LocalDateTime date, double totalPrice, int[] products){
        this.number = number;
        this.cashier = cashier;
        this.date = date;
        this.totalPrice = totalPrice;
        this.products = products;
    }
    public void showReceipt(){
        System.out.println("Сметка номер " + number + "\nКасиер: " + cashier.getName() + "\nДата: " + date + "\nОбща стойност: " + totalPrice + "\nПродукти:\n");
    }

}
