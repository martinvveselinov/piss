package com.company;

import javax.swing.plaf.synth.SynthLookAndFeel;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

public class Store {
    private ArrayList<Cashier> workers;
    private ArrayList<Product> products;
    private ArrayList<Receipt> receipts;
    private double salaries;
    private double deliverySpendings;
    private double revenue;

    public Store(){
        workers = new ArrayList<>();
        products = new ArrayList<>();
        receipts = new ArrayList<>();
        salaries = 0;
        deliverySpendings = 0;
        revenue = 0;
    }
    public void getProducts(){
        for(int i = 0; i < products.size(); ++i){
            System.out.print(i+1 + ". " + products.get(i).getName());
        }
    }
    public double getSalaries(){
        return salaries;
    }
    public double getDeliverySpendings(){
        return deliverySpendings;
    }
    public double getSales(){
        return revenue;
    }
    public double getRevenue(){
        return revenue-deliverySpendings-salaries;
    }
    public void quantity(){
        for(int i = 0; i < products.size(); ++i){
            System.out.println("Име на продукт: " + products.get(i).getName() + ", наличност: " + products.get(i).getQuantity());
        }
    }
    public void newClient(Scanner sc){
        int cashierInd = 0;
        if(workers.size() == 0){
            System.out.println("Няма налични касиери!");
            return;
        }
        else if(workers.size() > 1) {
            System.out.println("При кой касиер е клиента? Въведете номер от 1 до " + workers.size());
            cashierInd = sc.nextInt() - 1;
        }
        boolean enoughMoney = true;
        System.out.println("Колко продукта иска да купи клиента?");
        int productCount = sc.nextInt();
        int order[] = new int[productCount*2];
        System.out.println("Колко пари има клиента?");
        double money = sc.nextDouble();
        System.out.println("В магазина има следните продукти:");
        for(int i = 0; i < products.size(); ++i){
            System.out.println(i+1 + ". " + products.get(i).getName());
        }
        int ind = 0;
        double bill = 0;
        for(int i = 0; i < productCount; ++i){
            System.out.println("Въведете номер на продукт " + (i+1));
            order[ind] = sc.nextInt();
            System.out.println("Въведете брой: ");
            order[ind + 1] = sc.nextInt();
            if(order[ind]-1 > 0 && order[ind]-1 < products.size()){
                if(products.get(order[ind]-1).getQuantity() >= order[ind+1]){
                    if(money >= bill + products.get(order[ind]-1).getPrice())
                    {
                        bill += products.get(order[ind]-1).getPrice();
                    }
                    else{
                        enoughMoney = false;
                        break;
                    }
                }
                else{
                    System.out.println("Няма достатъчна наличност. Въведете следващия продукт!");
                }
            }
            else{
                System.out.println("Няма такъв продукт в магазина.");
            }
            ind += 2;
        }
        if(!enoughMoney){
            System.out.println("Клиентът няма достатъчно пари, за да си плати сметката.");
        }
        else{
            for(int i = 0; i < productCount*2; i+=2){
                for(int j = 0; j < products.size(); ++j){
                    if(order[i]-1 == products.get(j).getID()){
                        products.get(j).setQuantity(products.get(j).getQuantity()-order[i+1]);
                    }
                }
            }

            Receipt newReceipt = new Receipt(receipts.size()+1, workers.get(cashierInd), LocalDateTime.now(), bill, order);
            receipts.add(newReceipt);
            revenue += bill;
            System.out.println("Поръчката е изпълнена");
        }
    }
    public void addCashier(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Информация за касиер: ");
        System.out.println("ID на касиер: ");
        int ID = sc.nextInt();
        System.out.println("Име на касиер: ");
        sc.nextLine();
        String name = sc.nextLine();
        System.out.println("Заплата на касиер: ");
        double salary = sc.nextDouble();
        salaries += salary;
        Cashier newCashier = new Cashier(ID, name, salary);
        workers.add(newCashier);
    }
    public void load(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Информация за зарежданата стока: ");
        System.out.println("ID на стока: ");
        int ID = sc.nextInt();
        System.out.println("Име на стока: ");
        sc.nextLine();
        String name = sc.nextLine();
        System.out.println("Доставна цена на стока: ");
        double delivery = sc.nextDouble();
        System.out.println("Продажна цена на стока: ");
        double sell = sc.nextInt();
        System.out.println("Поръчан брой: ");
        int quantity = sc.nextInt();
        deliverySpendings += delivery * quantity;
        System.out.println("Категория на стока: ");
        sc.nextLine();
        String category = sc.nextLine();

        Product newProduct = new Product(ID, name, delivery, sell, quantity, category);
        products.add(newProduct);
    }
}
