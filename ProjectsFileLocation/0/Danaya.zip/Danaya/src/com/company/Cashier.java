package com.company;

public class Cashier {
    private String name;
    private int ID;
    private double salary;
    public Cashier(int ID, String name, double salary){
        this.ID = ID;
        this.name = name;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }
}
