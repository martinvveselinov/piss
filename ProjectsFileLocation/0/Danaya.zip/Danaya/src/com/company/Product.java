package com.company;

public class Product {
    private int ID;
    private String name;
    private double deliveryPrice;
    private double sellPrice;
    private int quantity;
    private String category;
    public Product(int ID, String name, double deliveryPrice, double sellPrice, int quantity, String category){
        this.ID = ID;
        this.name = name;
        this.deliveryPrice = deliveryPrice;
        this.sellPrice = sellPrice;
        this.quantity = quantity;
        this.category = category;
    }
    public String getName(){
        return name;
    }
    public int getQuantity(){
        return quantity;
    }
    public double getPrice(){
        return sellPrice;
    }
    public void setQuantity(int newQuantity){
        this.quantity = newQuantity;
    }
    public int getID(){
        return ID;
    }

}
