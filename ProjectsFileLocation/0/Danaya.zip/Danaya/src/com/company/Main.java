package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Store mag = new Store();
	    System.out.println("Изберете опция:");
        System.out.println("1. Зареждане на стока");
        System.out.println("2. Преглед на наличност");
        System.out.println("3. Добавяне на касиер");
        System.out.println("4. Нов клиент");
        System.out.println("5. Разходи за заплата");
        System.out.println("6. Разходи за зареждане на стоки");
        System.out.println("7. Приходи от продадена стока");
        System.out.println("8. Обща печалба на магазина");
        System.out.println("9. Изход");
        while(true){
            System.out.println("Въведете избора си: ");
            int choice = sc.nextInt();
            while(choice < 1 || choice > 9){
                System.out.println("Няма такава опция. Въведете избора си: ");
                choice = sc.nextInt();
            }
            switch (choice){
                case 1:
                {
                    System.out.println("Избрахте 1. Въвеждане на стока.");
                    mag.load();
                    break;
                }
                case 2:
                {
                    System.out.println("Избрахте 2. Преглед на наличността.");
                    mag.quantity();
                    break;
                }
                case 3:
                {
                    System.out.println("Избрахте 3. Добавяне на касиер.");
                    mag.addCashier();
                    break;
                }
                case 4:
                {
                    System.out.println("Избрахте 4. Нов клиент.");
                    mag.newClient(sc);
                    break;
                }
                case 5:
                {
                    System.out.println("Избрахте 5. Разходи за заплати.");
                    System.out.println("Общи разходи за заплати: " + mag.getSalaries() + " лв.");
                    break;
                }
                case 6:
                {
                    System.out.println("Избрахте 6. Разходи за зареждане на стока.");
                    System.out.println("Общи разходи за зареждане: " + mag.getDeliverySpendings() + " лв.");
                    break;
                }
                case 7:
                {
                    System.out.println("Избрахте 7. Приходи от продадена стока.");
                    System.out.println("Общи приходи от стока: " + mag.getSales() + " лв.");
                    break;
                }
                case 8:
                {
                    System.out.println("Избрахте 8. Обща печалба на магазина.");
                    System.out.println("Обща печалба: " + mag.getRevenue() + " лв.");
                    break;
                }
                case 9:
                {
                    System.out.println("Избрахте 9. Изход.");
                    return;
                }
                default:
                    break;
            }
        }

    }
}
