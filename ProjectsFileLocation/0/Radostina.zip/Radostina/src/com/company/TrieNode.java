package com.company;

public class TrieNode { //class - a single node from the Trie
    TrieNode[] children = new TrieNode[26]; //26 because the English alphabet is 26 letters
    String word; //the word that it represents
    int childCount = 0;
}
