package com.company;

import java.util.*;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors

//used Data Structure is Trie - perfect for fast searching of words, good fit for a Dictionary, like this task
//https://www.geeksforgeeks.org/trie-insert-and-search/

public class Trie { //main class of the program
    public static void main(String[] args) {
        Trie trie = new Trie(); //create new object of type Trie
        try { //read from file logic
            File myObj = new File("input.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine(); //take file content word by word
               trie.addWord(data); //insert each word in the Trie object
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        String secret = trie.getRandomWord(); //the Trie object has function getRandomWord() to find a random word in the list of words
        int length = secret.length(); //length of the random word
        int[] mask = new int[length]; //mask of the word (if word is "automobile", mask will be "0000000000". 0 - hidden letter, 1 - found letter
        //in the beginning it's all 0, and if we find a letter, the position of the letter becomes 1
        int guessed = 0; //number of guessed letters. If its equal to length, then the word is complete
        for(int i = 0; i < length; ++i){ //set all elements of the mask to 0 (all are hidden)
            mask[i] = 0;
        }
        Scanner sc = new Scanner(System.in);
        while(guessed != length){//infinite loop - while there are hidden letters, continue guessing
            System.out.println();
            for(int i = 0; i < length; ++i){//Show the current state of the word ( ? ? a ? a ? r t) ?- hidden, letter-  found
                if(mask[i] == 0) System.out.print("? "); //check if the current letter is hidden and print ?
                else System.out.print(secret.charAt(i)); //check if the letter is found and print it
            }
            System.out.println("\nEnter your guess: ");
            char c = sc.next().charAt(0); //enter the letter you want to guess
            System.out.println();
            if(secret.contains(Character.toString(c))){ //if the secret contains the letter
                for(int i = 0; i < length; ++i){ //check where in the secret is the letter and show it and change the mask
                    if(secret.charAt(i) == c && mask[i] == 0){
                        mask[i] = 1; //mask = 1 -> this letter is visible
                        guessed++; //increase guessed letters
                    }
                }
            }
            else System.out.println("Letter is not in the secret word!!");
        }
        System.out.println(secret); //after the loop we show the secret and Congratulations message
        System.out.println("Congratulations, you guessed the word!");
    }
    private Random random; //using Ranodm to take a random value
    private TrieNode root; //root of the trie - object TrieNode
    Trie() { //constructor of the main class.
        root = new TrieNode(); //root is a TrieNode object
        random = new Random();
    }
    private void addWord(String word) { //method to add new word to the Trie
        //The idea in my solution is to keep a child count in a parent. When a word is added, the child count of all the trie nodes along that path is incremented.
        TrieNode iter = root;
        iter.childCount++;
        for (char c : word.toCharArray()) {
            if(c - 'a' >= 0 && c - 'a' < 26) { //check if the character is letter (symbols are not allowed)
                if (iter.children[c - 'a'] == null)//if there is no letter in this node, add it
                    iter.children[c - 'a'] = new TrieNode(); //addint new node to the childrens of the current node

                iter = iter.children[c - 'a']; //go to the new position and resume from there
                iter.childCount++;
            }
            else continue; //skip if not a letter
        }
        iter.word = word;
    }
    private String getRandomWord() { //method to get a random word
        int index = random.nextInt(root.childCount);//childCount is the number of words in the Trie
        return getWordAtIndex(index); //get the word from the Trie at index
    }
    private String getWordAtIndex(int index) { //method to get the word at the specific index
        if (index >= root.childCount) return null;
        int curr = 0;
        TrieNode node = root;
        while (true) {
            for (TrieNode n : node.children) {
                if (n != null) {
                    if (curr + n.childCount > index + 1) {
                        node = n;
                        break;
                    } else if (curr + n.childCount == index + 1) { //found the word
                        if (n.word != null) {
                            return n.word;
                        }
                        node = n;
                        break;
                    }
                    curr += n.childCount;
                }
            }
        }
    }
}
