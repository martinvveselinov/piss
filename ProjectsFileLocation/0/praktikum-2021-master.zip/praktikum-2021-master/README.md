# Практикум 2021

### Клониране и стартиране на проекта

Препоръчителни развойни среди

VSCode

https://code.visualstudio.com/

WebStorm или друг продукт на jetbrains за уеб девелопмънт

https://www.jetbrains.com/webstorm/promo


За да свалите проекта ви трябва инсталиран git

https://git-scm.com/downloads
