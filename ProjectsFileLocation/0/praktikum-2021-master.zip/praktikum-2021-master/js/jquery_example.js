$(function() {
    console.log('Document is rendered and we have an access to all the elements');

});