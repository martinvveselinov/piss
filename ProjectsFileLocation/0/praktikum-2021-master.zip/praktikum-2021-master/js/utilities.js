export function getFullName(firstName = "Alexander", lastName = "Petrov"){
    return `${firstName} ${lastName}`;
}

export const settings = {
    apiKey: '12312312',
    time: '1d',
}


